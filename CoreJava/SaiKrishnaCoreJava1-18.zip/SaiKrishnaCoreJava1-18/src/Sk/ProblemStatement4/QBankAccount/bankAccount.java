package Sk.ProblemStatement4.QBankAccount;

public class bankAccount {
	int accountNumber;
	String name;
	String accountType;
	double balance;

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		if (balance < 1000) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nw) {
				System.out.println("Balance is low. Bal: " + balance);
			}
			return balance;
		} else if (accountType == "current" && balance < 5000) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nf) {
				System.out.println("Balance is low as per your account type.");
				System.out.println("Account Type: " + accountType);
			}
		} else if (balance < 0) {
			System.out.println("Negitive Balance: " + balance);
		}
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public bankAccount(int accountNumber, String name, String accountType, double balance) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.accountType = accountType;
		this.balance = balance;
	}

	void deposit(double bal) {
		if (bal < 0) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nf) {
				System.out.println("Negitive Amount cant be depositedDeposit");
			}
		} else {
			balance = getBalance() + bal;
			System.out.println("Current Balance is : " + balance);
		}
	}

	public void withdraw(double bal) {
		if (bal > 1000) {
			try {
				throw new NumberFormatException();
			} catch (NumberFormatException nf) {
				System.out.println("InSuffient Balance");
			}
		} else {
			balance = getBalance() - bal;
			System.out.println("Current Balance is : " + balance);
		}
	}

	void info() {
		System.out.println("Holder name: " + name);
		System.out.println("Account Number: " + accountNumber);
		System.out.println("Account Type: " + accountType);
		System.out.println("Balance: " + balance);
	}

	void display() {
		System.out.println("Balance is : " + getBalance());
	}

	public static void main(String[] args) {
		String name = "Saikrishna";
		String type = "savings";
		bankAccount bA = new bankAccount(100, name, type, 2000);
		bA.info();
		bA.deposit(2000);
		bA.display();
		bA.withdraw(500);
		bA.getBalance();
		bA.display();

	}

}
