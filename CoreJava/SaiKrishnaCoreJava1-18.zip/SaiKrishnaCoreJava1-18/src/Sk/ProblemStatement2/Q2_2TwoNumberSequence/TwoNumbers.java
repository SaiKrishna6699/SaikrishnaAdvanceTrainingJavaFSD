package Sk.ProblemStatement2.Q2_2TwoNumberSequence;

import java.util.*;

public class TwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Two Numbers: ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		sc.close();
		int i = 1, n = 15;
		
		while(i<=n) {
			System.out.print(a + ", ");
			int nextTerm = a+b;
			a = b;
			b = nextTerm;
			i++;
		}
	}
}