package Sk.ProblemStatement2.Q2_1StringThroughCommandLine;

import java.util.*;

public class Q2_1 {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the String: ");
		String a = s.nextLine();
		s.close();
		
		int stringLength = a.length();

		String b = a.toUpperCase();
		
		String c = "";
		
		System.out.println(b);
		
		for (int i = stringLength - 1; i >= 0; i--) {
			c = c + b.charAt(i);
		}

		if (b.equals(c)) {
			System.out.printf(b + " is a palindrome.");
		} else {
			System.out.printf(b + " is not a palindrome.");
		}
	}
}
