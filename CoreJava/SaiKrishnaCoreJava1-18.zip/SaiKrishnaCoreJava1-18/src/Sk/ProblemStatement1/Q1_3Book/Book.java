package Sk.ProblemStatement1.Q1_3Book;

public class Book{
	private String book_Title;
	private double book_Price;
	
	public Book(String book_Title, double book_Price) {
		super();
		this.book_Title = book_Title;
		this.book_Price = book_Price;
	}
	public String getBook_Title() {
		return book_Title;
	}
	public void setBook_Title(String book_Title) {
		this.book_Title = book_Title;
	}
	public double getBook_Price() {
		return book_Price;
	}
	public void setBook_Price(double bookprice) {
		this.book_Price = bookprice;
	}
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("book_title: "+this.book_Title);
	      System.out.println("book_price: "+this.book_Price);
		
	}
	
}