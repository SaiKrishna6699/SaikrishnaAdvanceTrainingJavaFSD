package Sk.ProblemStatement1.Q1_4ModifyRectangle;

import java.util.Scanner;

public class TestRectangle extends Rectangle {

	public TestRectangle(double length, double breadth) {
		super(length, breadth);
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the value of X: ");
		double x = s.nextInt();
		System.out.println();
		System.out.print("Enter the value of Y:");
		double y = s.nextInt();
		System.out.println();
		s.close();
		
		Rectangle rec1 = new Rectangle(x, y);
		rec1.printData();
		rec1.printArea();
		rec1.printPerimeter();
	}
}