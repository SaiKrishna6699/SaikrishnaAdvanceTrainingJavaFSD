package Sk.ProblemStatement1.Q1_4ModifyRectangle;

class Rectangle {
	private double length = 1;
	private double breadth = 1;

	public Rectangle(double length, double breadth) {
		if ((0<length)&&(length<20) && ((0<breadth)&&(breadth)<20)) {
		this.length = length;
		this.breadth = breadth;
		}
	}

	public double getLength() {
		return length;
	}


	public double getBreadth() {
		return breadth;
	}

	public void printData() {
		System.out.printf("Length: " + length + "\n");
		System.out.printf("Breadth: " + breadth + "\n");
	}

	public void printArea() {
		double area = length * breadth;
		System.out.println("Area: " + area);
	}

	public void printPerimeter() {
		double perimeter = 2 * (length + breadth);
		System.out.println("Perimeter: " + perimeter);
	}

}
