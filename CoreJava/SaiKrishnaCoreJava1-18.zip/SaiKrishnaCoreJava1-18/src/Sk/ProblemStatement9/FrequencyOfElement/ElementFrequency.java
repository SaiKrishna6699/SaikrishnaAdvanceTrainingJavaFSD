package Sk.ProblemStatement9.FrequencyOfElement;

import java.util.*;

class ElementFrequency {
	public static void findFrequency(int[] array, int left, int right, Map<Integer, Integer> frequency) {
		if(left > right) {
			return;
		}
		if(array[left] == array[right]) {
			Integer count = frequency.get(array[left]);
			if (count == null) {
				count = 0;
			}
			
			frequency.put(array[left], count + (right-left+1));
			return;
		}
		
		int mid = (left + right)/2;
		
		findFrequency(array, left, mid, frequency);
        findFrequency(array, mid + 1, right, frequency);
	}
	
	public static void main(String[] args)
    {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of Array"); //size 12
		int n = sc.nextInt();
		int[] array = new int[n];
        //int[] array = { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
		
		for (int i=0; i<array.length; i++) {
			System.out.println("Enter the element at index: "+ i);
			array[i] = sc.nextInt();
		}
 
        Map<Integer, Integer> frequency = new HashMap<>();
        findFrequency(array, 0, array.length - 1, frequency);
        
        for(Map.Entry<Integer, Integer> set : frequency.entrySet()) {
        	System.out.println(set.getKey()+" occurs "+set.getValue()+" tiimes ");
        }

    }
}
