package Sk.ProblemStatement11.CoinChange;

import java.util.Scanner;
import java.util.Vector;

class CoinChange {
	static int change[] = { 1, 2, 5, 10, 20, 50, 100, 500, 1000 };
	static int n = change.length;

	static void findMin(int V) {
		Vector<Integer> ans = new Vector<>();

		for (int i = n - 1; i >= 0; i--) {

			while (V >= change[i]) {
				V -= change[i];
				ans.add(change[i]);
			}
		}

		for (int i = 0; i < ans.size(); i++) {
			System.out.print(" " + ans.elementAt(i));

		}
		System.out.println("\n The minimum number of coins is " + ans.size());
	}

	public static void main(String[] args) {
		Scanner sn = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sn.nextInt();
		sn.close();

		System.out.print(" Following is minimal number " + "of change for " + n + ": ");
		findMin(n);
	}
}
