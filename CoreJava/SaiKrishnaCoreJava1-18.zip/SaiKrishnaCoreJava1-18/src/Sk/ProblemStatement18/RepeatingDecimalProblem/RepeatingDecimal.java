package Sk.ProblemStatement18.RepeatingDecimalProblem;

import java.util.*;

public class RepeatingDecimal{
	static String fractionToDecimal(int numr, int denr)
    {
		String res = "";
		
		HashMap<Integer, Integer> mp = new HashMap<>();
        mp.clear();
        
        int rem = numr % denr;
        while ((rem != 0) && (!mp.containsKey(rem)))
        {
        	mp.put(rem, res.length());
        	rem = rem * 10;
        	int res_part = rem / denr;
            res += String.valueOf(res_part);
            rem = rem % denr;
        }
        
        if(rem == 0) {
        	return "";
        }else if(mp.containsKey(rem)) {
        	return res.substring(mp.get(rem));
        }
        return "";    
    }
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Numerator: ");
		int numr = sc.nextInt();
		System.out.print("Enter the denominator");
		int denr = sc.nextInt();
		double ans = numr % denr;
		System.out.println("("+numr+"/"+denr+")");
		String result = fractionToDecimal(numr,denr);
		String r = "0";
		String f = result.toString();
		String m = r+"."+f;
		double a = ans + Double.parseDouble(m);
		sc.close();
		if (result == "")
            System.out.print("No recurring sequence");
        else
            System.out.print(a+"-> here "+result+ " is the Recurring sequence " );
		
	}
}