package Sk.ProblemStatement14.MergeArrayNSort;

import java.util.*;

class MergeArrayNSort {
	public static void sortedMerge(int arr1[], int arr2[], int result[], int n, int m) {
		int i=0,j=0,k=0;
		
		while(i<n) {
			result[k] = arr1[i];
			i++;
			k++;
		}
		
		while(j<m) {
			result[k] = arr2[j];
			j++;
			k++;
		}
		
		Arrays.sort(result);
	}
	
	public static void main(String[] args) {
		int m,n;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of First Array: ");
		m=sc.nextInt();
		int a[] = new int[m];
		for(int i=0; i<m; i++) {
			a[i] = sc.nextInt();
		}
		
		System.out.print("Enter the size of Second Array: ");
		n=sc.nextInt();
		int b[] = new int[n];
		for(int j=0; j<n; j++) {
			b[j]=sc.nextInt();
		}
		sc.close();
		
		int result[] = new int[m+n];
		sortedMerge(a,b,result,m,n);
		
		
		System.out.print("Sorted Merged Array: ");
		for(int i=0; i<result.length; i++) {
			System.out.print(" "+result[i]);
		}
	}
}
