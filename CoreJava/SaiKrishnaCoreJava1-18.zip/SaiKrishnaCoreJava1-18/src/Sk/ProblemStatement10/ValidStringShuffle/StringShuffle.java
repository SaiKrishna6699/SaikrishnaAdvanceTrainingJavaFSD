package Sk.ProblemStatement10.ValidStringShuffle;
import java.util.*;

class StringShuffle {
	public static boolean isInterleaving(String First, String Second, String Third) {

		if (First.length() == 0 && Second.length() == 0 && Third.length() == 0) {
			return true;
		}

		if (Third.length() == 0) {
			return false;
		}

		boolean one = (First.length() != 0 && Third.charAt(0) == First.charAt(0)) &&
				isInterleaving(First.substring(1), Second, Third.substring(1));

		boolean two = (Second.length() != 0 && Third.charAt(0) == Second.charAt(0)) &&
				isInterleaving(First, Second.substring(1), Third.substring(1));

		return one || two;
	}
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The First String :");
		String str1 = sc.nextLine();
		System.out.println("Enter The Second String :");
		String str2 = sc.nextLine();
		System.out.println("Enter The Third String :");
		String str3 = sc.nextLine();
		
		sc.close();
		
		if (isInterleaving(str1, str2, str3)) {
			System.out.print("True: Third String is valid shuffle of First and Second String");
		} else {
			System.out.print("False: Third String is not a valid shuffle of First and Second String");
		}
	}
}
