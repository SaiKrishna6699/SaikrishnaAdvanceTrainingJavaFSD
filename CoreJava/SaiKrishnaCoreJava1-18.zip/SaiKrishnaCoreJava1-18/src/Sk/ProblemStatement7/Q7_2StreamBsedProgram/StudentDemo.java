package Sk.ProblemStatement7.Q7_2StreamBsedProgram;

import java.io.*;

public class StudentDemo {
	public static void main(String args[]) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("Enter roll number: ");
		int roll = Integer.parseInt(br.readLine());
		System.out.print("\nEnter name: ");
		String name = br.readLine();
		System.out.print("\nEnter age: <Age should be b/w 15 - 21 ");
		int age = Integer.parseInt(br.readLine());
		System.out.print("\nEnter course: ");
		String course = br.readLine();
		Student s = new Student(roll, name, age, course);
		s.display();
	}
}