package Sk.ProblemStatement3.Q3_1AbstractClass;

public abstract class Instrument {
	public abstract void play();
}
