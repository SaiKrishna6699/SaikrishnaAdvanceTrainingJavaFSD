package Sk.ProblemStatement3.Q3_1AbstractClass;

public class Piano extends Instrument {
	@Override
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");
	}

}
