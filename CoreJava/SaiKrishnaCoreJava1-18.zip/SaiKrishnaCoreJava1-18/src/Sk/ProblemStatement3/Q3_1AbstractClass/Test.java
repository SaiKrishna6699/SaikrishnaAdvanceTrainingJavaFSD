package Sk.ProblemStatement3.Q3_1AbstractClass;

import java.util.*;

public class Test {
	public static void main(String[] Args) {
		Instrument[] instruments = new Instrument[10];
		
		Random rd = new Random();
		int j = 0;
		for(j=0;j<10;j++) {
			int rdNum = rd.nextInt((3-1)+1)+1;
			
			if (rdNum == 1) {
				instruments[j] = new Piano();
			}
			else if (rdNum == 2) {
				instruments[j] = new Flute();
			}
			else if (rdNum == 3) {
				instruments[j] = new Guitar();
			}
			instruments[j].play();
			
		}
		
		for(j=0;j<10;j++) {
			if (instruments[j] instanceof Piano) {
				System.out.println("Piano is stored at index " + j);
			}
			else if (instruments[j] instanceof Flute) {
				System.out.println("Flute is stored at index " + j);
			}
			else if (instruments[j] instanceof Guitar) {
				System.out.println("Guitar is stored at index " + j);
			}
		}
	}
}
