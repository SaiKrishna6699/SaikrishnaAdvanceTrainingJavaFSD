package Sk.ProblemStatement5.Q5_1StringManipulation;

public class StringManipulation {

	public static void main(String[] args) {

		String txt = "JAVA is Simple";

		System.out.println(txt.toUpperCase()); // UpperCase

		System.out.println(txt.toLowerCase()); // LowerCase

		String[] words = txt.split("\\s"); // 1st words of letter
		for (String w : words) {
			System.out.print(w.charAt(0));
			System.out.print(" ");
		}
		System.out.println(" ");

		String[] words1 = txt.split(" "); // Change order
		StringBuilder reverseString = new StringBuilder();

		for (int i = words.length - 1; i >= 0; i--) {
			reverseString.append(words[i]).append(" ");
		}
		System.out.println(reverseString);

		// String Builder reverse
		StringBuilder words2 = new StringBuilder(reverseString);

		StringBuilder reverseStr = words2.reverse();
		System.out.println(reverseStr.toString());

		// Total Length
		System.out.println("Total Length" + txt.length());
	}

}
