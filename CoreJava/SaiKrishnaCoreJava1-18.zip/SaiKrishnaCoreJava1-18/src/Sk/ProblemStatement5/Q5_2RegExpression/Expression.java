package Sk.ProblemStatement5.Q5_2RegExpression;

public class Expression {
	public static void main(String[] args) {
		String s= (" 23  +  45  -  (  343  /  12  ) ");
		String[] w=s.split(" ");
		
		
		System.out.println("***Output***");
		for(String w1:w){  
			System.out.println(w1); 
		}
	}
}
