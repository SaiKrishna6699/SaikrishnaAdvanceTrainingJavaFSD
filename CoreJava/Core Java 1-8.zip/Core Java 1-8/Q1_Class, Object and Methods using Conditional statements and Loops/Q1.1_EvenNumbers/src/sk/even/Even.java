package sk.even;
import java.util.Scanner;


public class Even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the value of n: ");
		int n = sc.nextInt();
		System.out.println();
		sc.close();
		System.out.println("Even Numbers in range of " + n + " is/are :");
		for(int i=0; i<=n; i++) {
			if (i>0 && i%2==0) {
				System.out.print(i + " ");
			}
		}

	}
}
