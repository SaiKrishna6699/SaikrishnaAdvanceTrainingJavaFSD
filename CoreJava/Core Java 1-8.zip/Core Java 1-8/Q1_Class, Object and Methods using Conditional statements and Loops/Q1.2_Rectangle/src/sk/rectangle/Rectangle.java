package sk.rectangle;

class Rectangle {
	private int length = 0;
	private int breadth = 0;

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}
	
	public void printData() {
		System.out.printf("Length: " + length +"\n");
		System.out.printf("Breadth: " + breadth +"\n");
	}
	
	public void printArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
	}
}
