package sk.rectangle;

import java.util.*;

public class TestRectangle extends Rectangle {

	public TestRectangle(int length, int breadth) {
		super(length, breadth);
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the value of X: ");
		int x = s.nextInt();
		System.out.println();
		System.out.print("Enter the value of Y:");
		int y = s.nextInt();
		System.out.println();
		s.close();
		
		Rectangle rec1 = new Rectangle(x, y);
		rec1.printData();
		rec1.printArea();
	}
}
