package sk;

import java.util.*;

public class StudentList {
	public static void main(String[] args) {
		ArrayList<String> a1 = new ArrayList<String>();
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of students:");
		n = sc.nextInt();
		System.out.println("Enter the student names:");
		for (int i = 0; i < n; i++) {
			a1.add(sc.next());
		}
		System.out.println("Student list:");
		for (String a : a1) {
			System.out.print("Enter the name of the student to be searched: ");
			String st = sc.next();
			int position = Collections.binarySearch(a1, st);
			System.out.print("\n");
			if (position == -1) {
				System.out.println("Stundent not found!!.");
			} else {
				System.out.println("Position of " + st + " is:" + position);
			}
		}
		sc.close();
	}
}
