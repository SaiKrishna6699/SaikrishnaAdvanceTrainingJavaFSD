package sk;

public class medicine {
	public void displayLabel() {
		System.out.println("Company : Apollo Pharmacy");
		System.out.println("Address : Tirupathi");
	}
}

class Tablet extends medicine {

	public void displayLabel() {
		System.out.println("Medicine : Tablet");
		System.out.println("Store in a cool dry place.");
	}
}

class Syrup extends medicine {
	public void displayLabel() {
		System.out.println("Medicine : Syrup");
		System.out.println("Check the expiration before taking the medincine");
	}
}

class Ointment extends medicine {
	public void displayLabel() {
		System.out.println("Medicine : Ointment");
		System.out.println("External use only");
	}
}