package sk;

import java.io.*;
import java.util.*;

public class DataTransfer{
	public static void copyData(File a, File b) throws Exception{
		FileInputStream inputStream = new FileInputStream(a);
		FileOutputStream outputStream = new FileOutputStream(b);
		
		try {
			int i;
			while((i = inputStream.read()) != -1) {
				outputStream.write(i);
			}
		}
		catch(Exception e) {
			System.out.println("Error Found." + e.getMessage());
		}
		finally {
			if(inputStream != null) {
				inputStream.close();
			}
			if(outputStream != null) {
				outputStream.close();
			}
		}
		System.out.println("File Copied");
	}
	
	public static void main(String[] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name of the file from where the data would be copied :");
		String a = sc.nextLine();
		//Create Two Files in the Location
		File a1 = new File(a);
		System.out.println("Enter the name of the file from where the data would be written :");
		String b = sc.nextLine();
		File b1 = new File(b);
		sc.close();
		copyData(a1,b1);
	}
	
}