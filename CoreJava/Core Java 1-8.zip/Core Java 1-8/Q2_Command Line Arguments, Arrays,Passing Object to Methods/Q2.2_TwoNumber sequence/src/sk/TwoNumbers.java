package sk;

import java.util.*;

public class TwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		sc.close();
		int i = 1, n = 15;
		
		while(i<=n) {
			System.out.print(a + ", ");
			int nextTerm = a+b;
			a = b;
			b = nextTerm;
			i++;
		}
	}
}
