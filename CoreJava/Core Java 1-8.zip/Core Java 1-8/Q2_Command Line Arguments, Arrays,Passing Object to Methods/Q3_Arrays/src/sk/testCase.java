package sk;

import java.util.*;

public class testCase {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array: ");
		int n = sc.nextInt();
		ArrayList<Integer> A = new ArrayList<Integer>();
		for (int i = 0; i < n; i++) {
			A.add(sc.nextInt());
		}
		
		sc.close();
		
		int sum=0, avg;
		
		for (int i=0; i < A.size(); i++) {
			sum = sum + A.get(i); 
		}
		
		System.out.println("Sum of array is: "+sum);
		
		avg = sum/A.size();	
		
		System.out.println("Avg of the array is: "+avg);
		
		A.add(sum);
		
		A.add(avg);
		
		System.out.println("***Adding Sum and Avg into the Array***");
		for(int i=0; i<A.size(); i++) {
			System.out.printf(A.get(i) + ",");
		}
		
		
	}
}
