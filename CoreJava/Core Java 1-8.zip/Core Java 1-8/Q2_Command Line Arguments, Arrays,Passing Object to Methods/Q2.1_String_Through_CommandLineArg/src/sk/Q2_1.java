package sk;

import java.util.*;

public class Q2_1 {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		String a = s.nextLine();
		s.close();
		
		int stringLength = a.length();

		String b = "";
		
		System.out.println(a.toUpperCase());
		
		for (int i = stringLength - 1; i >= 0; i--) {
			b = b + a.charAt(i);
		}

		if (a.equals(b)) {
			System.out.printf(a + " is a palindrome.");
		} else {
			System.out.printf(a + " is not a palindrome.");
		}
	}
}
